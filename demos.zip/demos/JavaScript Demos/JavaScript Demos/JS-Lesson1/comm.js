var message
message="<h1> Hello From External JavaScript </h1>"